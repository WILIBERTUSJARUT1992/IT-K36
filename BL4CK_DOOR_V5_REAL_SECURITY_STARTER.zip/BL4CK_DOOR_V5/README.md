# BL4CK DOOR V5 — Real Security Check

Paket ini memisahkan frontend GitHub Pages dan backend Cloudflare Workers. Fitur yang memakai API tidak akan memberikan hasil palsu ketika API key belum dipasang.

## Fitur nyata
- URL reputation: Google Safe Browsing Lookup API.
- Email breach: Have I Been Pwned API v3 (memerlukan API key HIBP yang sesuai).
- Password exposure: Pwned Passwords range API dengan k-anonymity. Browser hanya mengirim 5 karakter awal hash SHA-1, bukan password.
- SHA-256: Web Crypto API lokal di browser.

## Belum termasuk
- Pemindaian port jaringan.
- Penetration testing otomatis.
- Audit kerentanan menyeluruh.
- Pemindaian file upload.
Hasil bersih bukan jaminan sistem aman.

## A. Siapkan Google Safe Browsing API
1. Buka Google Cloud Console dan buat/pilih project.
2. Aktifkan Safe Browsing API dan buat API key.
3. Batasi API key sesuai rekomendasi Google jika tersedia.
4. Simpan key sebagai secret di Cloudflare Worker dengan nama `GOOGLE_SAFE_BROWSING_KEY`.

Dokumentasi: https://developers.google.com/safe-browsing/v4/get-started

## B. Siapkan HIBP (opsional)
1. Daftar/akses API key Have I Been Pwned.
2. Email breach API membutuhkan key dan akses/plan yang sesuai.
3. Simpan sebagai secret `HIBP_API_KEY` di Cloudflare Worker.

Dokumentasi: https://haveibeenpwned.com/API/v3

Jika belum memiliki key, fitur email akan menampilkan pesan bahwa konfigurasi belum tersedia—tidak akan mengarang hasil.

## C. Deploy backend di Cloudflare (bisa dari browser HP)
1. Login ke https://dash.cloudflare.com/
2. Masuk Workers & Pages → Create → Worker.
3. Beri nama misalnya `bl4ck-door-api`.
4. Buka Edit Code, ganti isi kode dengan `worker/index.js` dari ZIP ini, lalu Deploy.
5. Buka Settings → Variables and Secrets.
6. Tambahkan secret:
   - `GOOGLE_SAFE_BROWSING_KEY` = API key Google.
   - `HIBP_API_KEY` = API key HIBP (opsional).
7. Tambahkan variable teks biasa:
   - `ALLOWED_ORIGIN` = `https://wilibertusjarut1992.github.io`
8. Deploy ulang jika diminta.
9. Catat alamat Worker, contoh `https://bl4ck-door-api.NAMA-AKUN.workers.dev`.

Cloudflare secrets docs: https://developers.cloudflare.com/workers/configuration/secrets/

## D. Hubungkan GitHub Pages
1. Buka `public/index.html`.
2. Cari baris `const API_BASE = "https://GANTI-NAMA-WORKER.workers.dev";`
3. Ganti dengan alamat Worker milik Anda.
4. Upload isi folder `public` ke root repository GitHub `IT-BL4CK-DOOR-I-M-WJ` (index.html harus di root), atau salin isi `public/index.html` ke index.html yang sudah ada.
5. Commit perubahan dan tunggu GitHub Pages selesai publish.
6. Buka website, tekan UJI KONEKSI BACKEND.

## E. Pengujian
- Backend health: buka `https://ALAMAT-WORKER/api/health` dari browser setelah domain Pages diizinkan. Uji utama tetap dari halaman GitHub Pages.
- URL: uji hanya URL yang aman untuk diperiksa; hasil berasal dari Google Safe Browsing.
- Email: gunakan email sendiri. Email dikirim ke HIBP untuk pencarian breach; jangan masukkan email orang lain tanpa izin.
- Password: jangan gunakan password utama. Password diproses di browser, prefix hash dikirim ke Pwned Passwords.

## Keamanan penting
- JANGAN menaruh API key di `index.html`, GitHub, atau repository publik.
- Jangan menaruh password, OTP, PIN, atau kredensial akun pada formulir.
- Batasi API key dan pantau pemakaian/kuota.
- Jangan mengaktifkan CORS untuk `*`; gunakan URL GitHub Pages Anda.
- Google Safe Browsing dan HIBP memiliki ketentuan layanan, batas, dan cakupan data sendiri.
