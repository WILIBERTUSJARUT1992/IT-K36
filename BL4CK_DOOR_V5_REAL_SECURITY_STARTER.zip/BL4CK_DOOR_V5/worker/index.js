const corsHeaders = {
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Max-Age": "86400"
};
function response(data, status, origin) {
  return new Response(JSON.stringify(data), { status, headers: {
    "Content-Type":"application/json; charset=utf-8",
    "Cache-Control":"no-store",
    "Access-Control-Allow-Origin": origin || "null",
    "Vary":"Origin",
    ...corsHeaders
  }});
}
function allowedOrigin(origin, env) {
  const allowed = (env.ALLOWED_ORIGIN || "").split(",").map(x=>x.trim()).filter(Boolean);
  return !!origin && allowed.includes(origin);
}
function validEmail(v){return typeof v==="string" && v.length<=254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)}
function validUrl(v){try{const u=new URL(v);return ["http:","https:"].includes(u.protocol) && v.length<=2048}catch{return false}}
export default {
 async fetch(request, env) {
   const origin=request.headers.get("Origin")||"";
   if(request.method==="OPTIONS") return new Response(null,{status:204,headers:{...corsHeaders,"Access-Control-Allow-Origin":allowedOrigin(origin,env)?origin:"null"}});
   if(!allowedOrigin(origin,env)) return response({error:"Origin tidak diizinkan."},403,"null");
   const url=new URL(request.url);
   if(request.method==="GET" && url.pathname==="/api/health"){
     return response({ok:true,product:"BL4CK DOOR V5",services:{
       googleSafeBrowsing:!!env.GOOGLE_SAFE_BROWSING_KEY,
       haveIBeenPwned:!!env.HIBP_API_KEY,
       passwordExposure:"Pwned Passwords range API (client-side k-anonymity)"
     }},200,origin);
   }
   if(request.method!=="POST") return response({error:"Method tidak didukung."},405,origin);
   let body; try{body=await request.json()}catch{return response({error:"JSON tidak valid."},400,origin)}
   if(url.pathname==="/api/url-check"){
     if(!validUrl(body.url)) return response({error:"URL tidak valid. Gunakan http atau https."},400,origin);
     if(!env.GOOGLE_SAFE_BROWSING_KEY) return response({error:"GOOGLE_SAFE_BROWSING_KEY belum dipasang di Cloudflare Worker."},503,origin);
     const endpoint="https://safebrowsing.googleapis.com/v4/threatMatches:find?key="+encodeURIComponent(env.GOOGLE_SAFE_BROWSING_KEY);
     const payload={client:{clientId:"bl4ck-door",clientVersion:"5.0"},threatInfo:{
       threatTypes:["MALWARE","SOCIAL_ENGINEERING","UNWANTED_SOFTWARE","POTENTIALLY_HARMFUL_APPLICATION"],
       platformTypes:["ANY_PLATFORM"],threatEntryTypes:["URL"],threatEntries:[{url:body.url}]
     }};
     try{
       const r=await fetch(endpoint,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
       const d=await r.json(); if(!r.ok)return response({error:"Google Safe Browsing menolak permintaan (HTTP "+r.status+")."},502,origin);
       const matches=d.matches||[];
       return response({malicious:matches.length>0,source:"Google Safe Browsing",threats:matches.map(x=>x.threatType),note:"Tidak ada kecocokan bukan jaminan mutlak bahwa URL aman."},200,origin);
     }catch{return response({error:"Gagal menghubungi Google Safe Browsing."},502,origin)}
   }
   if(url.pathname==="/api/email-check"){
     if(!validEmail(body.email))return response({error:"Alamat email tidak valid."},400,origin);
     if(!env.HIBP_API_KEY)return response({error:"HIBP_API_KEY belum dipasang. API email HIBP memerlukan kunci berlangganan."},503,origin);
     try{
       const r=await fetch("https://haveibeenpwned.com/api/v3/breachedAccount/"+encodeURIComponent(body.email)+"?truncateResponse=true",{headers:{"hibp-api-key":env.HIBP_API_KEY,"user-agent":"BL4CK-DOOR-V5"}});
       if(r.status===404)return response({found:false,breaches:[],source:"Have I Been Pwned"},200,origin);
       if(r.status===401||r.status===403)return response({error:"Kunci HIBP tidak valid atau akses API tidak tersedia."},502,origin);
       if(!r.ok)return response({error:"HIBP gagal memproses permintaan (HTTP "+r.status+")."},502,origin);
       const breaches=await r.json();
       return response({found:breaches.length>0,breaches:breaches.map(b=>({name:b.Name,date:b.BreachDate})),source:"Have I Been Pwned"},200,origin);
     }catch{return response({error:"Gagal menghubungi Have I Been Pwned."},502,origin)}
   }
   return response({error:"Endpoint tidak ditemukan."},404,origin);
 }
};